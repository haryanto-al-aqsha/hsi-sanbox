import './pages/login.dart';

import './pages/gallery_page.dart';

import './pages/photo_page.dart';
import 'package:flutter/material.dart';
import './pages/home_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  //const MyApp({supe//r.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
      initialRoute: HomePage.nameRoute,
      routes: {
        /* bisa juga dg ini
        '/homepage': (context) => HomePage(),
        '/gallery': (context) => GalleryPage(),
        '/photo': (context) => PhotoPage(),
        */
        HomePage.nameRoute: (context) => HomePage(),
        GalleryPage.nameRoute: (context) => GalleryPage(),
        PhotoPage.nameRoute: (context) => PhotoPage(),
        LoginPage.nameRoute: (context) => LoginPage(),
      },
    );
  }
}
