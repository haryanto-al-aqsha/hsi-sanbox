import './pages/page_satu.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PageSatu(),
      //home: Scaffold(
      //  body: Center(
      //    child: Text("Halloaa"),
      //  ),
      //  appBar: AppBar(
      //    title: Text("MyApp"),
      ///  ),
      //),
    );
  }
}
