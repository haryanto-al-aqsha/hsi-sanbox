import 'package:flutter/material.dart';
//import './page_satu.dart';

class PageDua extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page Dua"),
      ),
      body: Center(
        child: Text(
          "Ini page dua",
          style: TextStyle(
            fontSize: 40,
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.of(context).pop();
            //  Navigator.of(context).push(
            //    MaterialPageRoute(
            //      builder: (context) {
            //        return PageSatu();
            //      },
            //    ),
            //  );
          },
          child: Icon(Icons.keyboard_arrow_left)),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
