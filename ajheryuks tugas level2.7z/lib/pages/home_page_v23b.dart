import "dart:ui";

import "package:flutter/material.dart";
//import "./gallery_page.dart";

class HomePage extends StatelessWidget {
  //const HomePage({s//uper.key});
  static const nameRoute = '/homepage';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      /*appBar: AppBar(
        title: Text('Home Page2'),
      ),*/
      /*body: Center(
        child: Text(
          'HOME PAGEa',
          style: TextStyle(
            fontSize: 50,
          ),
        ), */

      body: ListView(
        children: [
          Container(
            height: 200,
            width: 150,
            color: Colors.white,
            //color: Color.fromARGB(255, 4, 80, 6),
            child: Image(image: AssetImage("images/Logo.png")),
          ),
          SizedBox(height: 50),
          Text(
            'Welcome To AjherYuk',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "Best and popular Apps for live education course from home",
            textAlign: TextAlign.center,
          ),
          ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed('/gallery');
              },
              child: Text('Get Started'),
              style: ElevatedButton.styleFrom(
                primary: Color(0xFFEC5F5F),
              )),
          /*Container(
            height: 200,
            width: 150,
            color: const Color.fromARGB(255, 184, 133, 133),
            //child: Image(image: AssetImage("images/Logo.png")),
          ),
          Container(
            height: 200,
            width: 150,
            color: Colors.amber,
            //color: Color.,
            //child: Image(image: AssetImage("images/Logo.png")),
          ), */
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).pushNamed('/gallery');
/*
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) {
              return GalleryPage();
            }),
          );
          */
        },
        child: Icon(Icons.arrow_right_alt),
      ),
    );
  }
}
