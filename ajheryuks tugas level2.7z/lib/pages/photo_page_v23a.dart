import "package:flutter/material.dart";

class PhotoPage extends StatelessWidget {
  //const HomePage({s//uper.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Photo Page"),
      ),
      body: Center(
        child: Text(
          "PHOTO PAGE",
          style: TextStyle(
            fontSize: 50,
          ),
        ),
      ),
    );
  }
}
