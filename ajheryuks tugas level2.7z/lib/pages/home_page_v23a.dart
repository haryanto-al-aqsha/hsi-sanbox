import "package:flutter/material.dart";
import "./gallery_page.dart";

class HomePage extends StatelessWidget {
  //const HomePage({s//uper.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Pagekua'),
      ),
      body: Center(
        child: Text(
          'HOME PAGEa',
          style: TextStyle(
            fontSize: 50,
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //Navigator.of(context).pushNamed('/gallery');

          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) {
              return GalleryPage();
            }),
          );
        },
        child: Icon(Icons.arrow_right_alt),
      ),
    );
  }
}
