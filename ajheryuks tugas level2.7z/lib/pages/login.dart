import "./photo_page.dart";
import "package:flutter/material.dart";

class LoginPage extends StatelessWidget {
  //const MyWidget({super.key});
  static const nameRoute = '/login';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: ListView(
        children: [
          Image.asset('images/Logo-only.png'),
          TextField(
            decoration: InputDecoration(
              label: Text('Email'),
            ),
          ),
          TextField(
            decoration: InputDecoration(
              label: Text('Password'),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              //Navigator.of(context).pushNamed('/login');
            },
            child: Text('Login'),
            style: ElevatedButton.styleFrom(
              primary: Color(0xFFEC5F5F),
            ),
          ),
          TextButton(
            onPressed: () {},
            child: Text('Forgot Password'),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 5,
                  color: Colors.green,
                ),
              ),
              Text('or'),
              Expanded(
                child: Container(
                  height: 5,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          Container(
            child: ElevatedButton(
              onPressed: () {
                //Navigator.of(context).pushNamed('/login');
              },
              child: Row(
                children: [
                  Text('Login with Facebook'),
                  Image.asset('images/facebook.png'),
                ],
              ),
              style: ElevatedButton.styleFrom(
                primary: Color(0xFFEC5F5F),
              ),
            ),
          ),
        ],
      ),
      /*body: Center(
      child: Text(
        'Login view is working',
        style: TextStyle(fontSize: 20),
        ),
      ),*/
    );
  }
}
